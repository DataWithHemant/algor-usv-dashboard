USV Plant Network — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR).
Period: Apr 2023 - Mar 2026 (Indian financial years). Data as of 31 Mar 2026.

Tables:
  sales_monthly: 1,944 rows
  prod_monthly: 468 rows
  down_monthly: 1,764 rows
  dev_monthly: 1,282 rows
  qa_monthly: 252 rows
  budget_monthly: 252 rows
  inv_monthly: 1,008 rows
  batch_register_sample: 5,760 rows
  dispatch_orders_sample: 5,280 rows
  deviation_log: 1,990 rows
  materials_monthly_position: 2,772 rows
